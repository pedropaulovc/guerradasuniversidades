package com.mac242.guerradasuniversidades.core.modelo;

public class StatusJogador {
	public String nome;
	public int HP, PE, FO, maxFO, taxaPE, taxaFO, taxaManutencao, taxaFuncionarios;
}
