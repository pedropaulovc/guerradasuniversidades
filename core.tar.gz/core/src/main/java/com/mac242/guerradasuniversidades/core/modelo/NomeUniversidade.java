package com.mac242.guerradasuniversidades.core.modelo;

public enum NomeUniversidade {
	USP, UNICAMP, UFSC;
}
