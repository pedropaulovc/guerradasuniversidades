package com.mac242.guerradasuniversidades.core.modelo;
public enum FocoAdministracao {
	BIOMEDICAS, EXATAS, HUMANAS, ESPORTES;
}