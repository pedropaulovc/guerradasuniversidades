package com.mac242.guerradasuniversidades.core.controle;

import com.mac242.guerradasuniversidades.core.modelo.FachadaJogador;
import com.mac242.guerradasuniversidades.core.modelo.NomeUniversidade;
import com.mac242.guerradasuniversidades.core.visao.VisaoGuerraDasUniversidades;

import react.UnitSlot;

public class TratadorAtacarOponente extends UnitSlot {
	
	private FachadaJogador jogador;
	private NomeUniversidade oponente;
	private VisaoGuerraDasUniversidades visao;

	public TratadorAtacarOponente definirJogador(FachadaJogador jogador){
		this.jogador = jogador;
		return this;
	}
	
	public TratadorAtacarOponente definirOponente(NomeUniversidade oponente){
		this.oponente = oponente;
		return this;
	}
	
	public TratadorAtacarOponente definirVisao(VisaoGuerraDasUniversidades visao){
		this.visao = visao;
		return this;
	}
	
	@Override
	public void onEmit() {
		String aviso = "";
		
		switch (jogador.atacar(oponente)) {
		case ALVO_MORTO:
			aviso = "O alvo está morto. Ataque falhou.";
			break;
		case FOCO_ZERO:
			aviso = "Você tem FO = 0. Ataque falhou.";
			break;
		case AUTO_ATAQUE:
			aviso = "Autoflagelação? Ataque falhou.";
			break;
		case SEM_SALA_COMPLETA:
			aviso = "Você não tem uma sala completa. Ataque falhou.";
			break;
		case SUCESSO:
			aviso = "Ataque bem sucedido.";
			break;
		default:
			break;
		}
		visao.obterTelaPrincipal().adicionarAviso(aviso);
		visao.exibirTela(visao.obterTelaPrincipal());
	}

}
