package com.mac242.guerradasuniversidades.core.modelo;

public enum ResultadoAtaque {
	SUCESSO, FOCO_ZERO, SEM_SALA_COMPLETA, AUTO_ATAQUE, ALVO_MORTO
}
