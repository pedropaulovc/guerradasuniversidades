package com.mac242.guerradasuniversidades.core.modelo;

public enum TipoNotificacao {
	COMPRA, DESTRUICAO, ATAQUE, ATUALIZACAO, MORTE, PERDA_HP, GREVE, DERROTA, VITORIA
}
