package com.mac242.guerradasuniversidades.core.modelo;

public class Main {
	public static void main(String[] args) {
		new InterfaceUsuario();
	}
}
